package com.example.UserData.Service;

public class UserDataService {

}
