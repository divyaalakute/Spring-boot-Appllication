package com.example.UserData.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.UserData.Domain.UserData;
import com.example.UserData.Repository.UserDataRepository;

@Controller
public class UserDataController {

	 @Autowired
	    private UserDataRepository userRepository;

	    @PostMapping("/users")
	    public UserData createUser(@RequestBody UserData user) {
	        // Generate password using JavaScript code
	        String password = generatePassword(user.getFirstName(), user.getMiddleName(), user.getLastName());
	        user.setPassword(password);

	        // Save user to the database
	        return userRepository.save(user);
	    }

	    // JavaScript code to generate password
	    private String generatePassword(String firstName, String middleName, String lastName) {
	        // JavaScript code to generate password
	        // For simplicity, you can assume this logic is implemented in JavaScript
	        // For example: var password = firstName.substring(0, 2) + middleName.substring(0, 2) + lastName.substring(0, 2) + Math.floor(100 + Math.random() * 900);
	    }
}
